========================================
forensics 1 (✯)
========================================

⏰ Temps de présentation: 200s (3 min 20)

✓ maths, algorithmique et crypto : 0 pts
✓ sécurité système.............. : 1 pts
✓ protocoles et réseaux......... : 1 pts
✓ reverse engineering........... : 0 pts


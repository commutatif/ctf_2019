========================================
chiffrement de vernam (✯✯)
========================================

⏰ Temps de présentation: 320s (5 min 20)

✓ maths, algorithmique et crypto : 4 pts
✓ sécurité système.............. : 0 pts
✓ protocoles et réseaux......... : 0 pts
✓ reverse engineering........... : 0 pts

